package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.Interns;

public interface InternsService {
	List<Interns> retrieveInternsService();
	Interns retrieveInternsByIdService(int internId);
	boolean registerInternService(Interns interns);
	boolean updateInternLevelService(Interns interns);
	boolean deleteInternByIdService(int internId);
}
