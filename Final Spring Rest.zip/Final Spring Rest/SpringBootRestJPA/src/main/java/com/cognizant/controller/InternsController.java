package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.entity.Interns;
import com.cognizant.service.InternsService;

@RestController
@RequestMapping("/interns")
public class InternsController {
	@Autowired
	private InternsService internService;
	@GetMapping("/allinterns")
	public ResponseEntity<List<Interns>> retrieveAllInterns(){
		
		List<Interns> internsList=internService.retrieveInternsService();
		ResponseEntity<List<Interns>> response=new ResponseEntity<List<Interns>>(internsList,HttpStatus.OK);
		return response;
	}
	@GetMapping("/intern/{internId}")
	public ResponseEntity<Interns> retrieveInternById(@PathVariable("internId") int internId){
		Interns interns=internService.retrieveInternsByIdService(internId);
		ResponseEntity<Interns> response=null;
		if(interns.getInternId()!=0){
		response=new ResponseEntity<Interns>(interns,HttpStatus.FOUND);
		}else{
		response=new ResponseEntity<Interns>(interns,HttpStatus.NOT_FOUND);

		}
		return response;
		
	}
	
	@PostMapping("internpersist")
	public ResponseEntity<Void> registerIntern(@RequestBody Interns interns){
		
		boolean registrationResult=internService.registerInternService(interns);
		
		ResponseEntity<Void> response=null;
		if(registrationResult){
			response=new ResponseEntity<Void>(HttpStatus.CREATED);
			
		}else{
			response=new ResponseEntity<Void>(HttpStatus.CONFLICT);

		}
		return response;	
	}
	
	@PutMapping("updateLevel")
	public ResponseEntity<Void> updateLevel(@RequestBody Interns interns)
	{
		boolean updateLevel=internService.updateInternLevelService(interns);
		ResponseEntity<Void> response=null;
		if(updateLevel==true)
			response=new ResponseEntity<Void>(HttpStatus.ACCEPTED);	
		else
			response=new ResponseEntity<Void>(HttpStatus.NOT_MODIFIED);
		return response;
	}
	
	@DeleteMapping("/deleteIntern/{internId}")
	public ResponseEntity<Void> deleteInternById(@PathVariable("internId") int internId){
		boolean removeIntern=internService.deleteInternByIdService(internId);
		ResponseEntity<Void> response=null;
		if(removeIntern){
		response=new ResponseEntity<Void>(HttpStatus.MOVED_PERMANENTLY);
		}else{
		response=new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		return response;
	}
}