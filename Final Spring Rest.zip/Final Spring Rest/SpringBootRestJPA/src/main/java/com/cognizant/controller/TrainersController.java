package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.entity.Trainers;
import com.cognizant.service.TrainersService;

@RestController
@RequestMapping("/trainers")
public class TrainersController {
	
	@Autowired
	private TrainersService trainersService;
	
	@GetMapping("trainerrecords")
	public ResponseEntity<List<Trainers>> getAllTrainers()
	{
		List<Trainers> trainerList=trainersService.retriveTrainerRecordsService();
		ResponseEntity<List<Trainers>> response=new ResponseEntity<List<Trainers>>(trainerList,HttpStatus.OK);
		return response;
	}
	
	@PostMapping("addTrainer")
	public ResponseEntity<Void> registerTrainer(@RequestBody Trainers trainer)
	{
		boolean registration=trainersService.addingTrainerService(trainer);
		
		ResponseEntity<Void> response=null;
		if(registration)
		{
			response=new ResponseEntity<Void>(HttpStatus.CREATED);
		}else{
			response=new ResponseEntity<Void>(HttpStatus.CONFLICT);			
		}
		return response;
	}
	
	@GetMapping("/trainer/{trainerId}")
	public ResponseEntity<Trainers> retrieveInternById(@PathVariable("trainerId") int trainerId){
		Trainers trainers=trainersService.retrieveTrainerByIdService(trainerId);
		ResponseEntity<Trainers> response=null;
		if(trainers.getTrainerId()!=0){
		response=new ResponseEntity<Trainers>(trainers,HttpStatus.FOUND);
		}else{
		response=new ResponseEntity<Trainers>(trainers,HttpStatus.NOT_FOUND);

		}
		return response;		
	}
	
	@PutMapping("updateTrainer")
	public ResponseEntity<Void> updateTrainerInfo(@RequestBody Trainers trainers)
	{
		boolean updationResult=trainersService.updateTrainerInfoService(trainers);
		ResponseEntity<Void> responseEntity=null;
		if(updationResult==false)
		{
			responseEntity=new ResponseEntity<Void>(HttpStatus.NOT_MODIFIED);
		}else{
			responseEntity=new ResponseEntity<Void>(HttpStatus.ACCEPTED);
		}
		return responseEntity;
	}
	
	@DeleteMapping("/deleteTrainer/{trainerId}")
	public ResponseEntity<Void> deleteTrainer(@PathVariable("trainerId") int trainerId)
	{
		boolean trainerDeletionResult=trainersService.deleteTrainerService(trainerId);
		ResponseEntity<Void> responseEntity=null;
		if(trainerDeletionResult){
		responseEntity=new ResponseEntity<Void>(HttpStatus.MOVED_PERMANENTLY);
		}else{
		responseEntity=new ResponseEntity<Void>(HttpStatus.NOT_FOUND);			
		}
		return responseEntity;
	}
}
