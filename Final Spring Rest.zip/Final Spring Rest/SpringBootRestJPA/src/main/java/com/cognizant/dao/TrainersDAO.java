package com.cognizant.dao;

import java.util.List;

import com.cognizant.entity.Trainers;

public interface TrainersDAO {

	List<Trainers> getAllTrainers();
	boolean addTrainer(Trainers trainer);
	Trainers getTrainerById(int trainerId);
	boolean updateTrainerInfo(Trainers trainers);
	boolean deleteTrainer(int trainerId);
}
