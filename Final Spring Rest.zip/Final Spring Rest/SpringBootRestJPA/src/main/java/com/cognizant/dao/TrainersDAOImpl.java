package com.cognizant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.entity.Trainers;
@Repository
public class TrainersDAOImpl implements TrainersDAO{

	@PersistenceContext
	private EntityManager manager;
	
	public List<Trainers> getAllTrainers() {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("findAllTrainers");
		List<Trainers> trainerList=query.getResultList();
		return trainerList;
	}

	@Transactional
	public boolean addTrainer(Trainers trainer) {
		// TODO Auto-generated method stub
		manager.persist(trainer);
		return true;
	}

	public Trainers getTrainerById(int trainerId) {
		// TODO Auto-generated method stub
		Trainers trainer=new Trainers();
		Query query=manager.createNamedQuery("findTrainerById");
		query.setParameter("Id", trainerId);
		trainer=(Trainers)query.getSingleResult();
		return trainer;
	}

	@Transactional
	public boolean updateTrainerInfo(Trainers trainers) {
		// TODO Auto-generated method stub
		manager.merge(trainers);
		return true;
	}

	@Transactional
	public boolean deleteTrainer(int trainerId) {
		// TODO Auto-generated method stub
		Trainers trainers=getTrainerById(trainerId);
		manager.remove(trainers);
		return true;
	}

}
