package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.TrainersDAO;
import com.cognizant.entity.Trainers;
import com.cognizant.exception.TrainersException;

@Service
public class TrainersServiceImpl implements TrainersService{

	@Autowired
	private TrainersDAO trainersDAO;
	
	public List<Trainers> retriveTrainerRecordsService() {
		// TODO Auto-generated method stub
		List<Trainers> trainerList=trainersDAO.getAllTrainers();
		if(trainerList.isEmpty())
		{
			throw new TrainersException("There are no trainer records to be displayed");
		}
		else{
		return trainerList;
		}
	}

	public boolean addingTrainerService(Trainers trainer) {
		// TODO Auto-generated method stub
		boolean recordAddStatus=trainersDAO.addTrainer(trainer);
		if(recordAddStatus)
		{	
			return true;
		}else{
			return false;
		}
	}

	public Trainers retrieveTrainerByIdService(int trainerId) {
		// TODO Auto-generated method stub
		Trainers trainer=new Trainers();
		trainer=trainersDAO.getTrainerById(trainerId);
		if(trainer.getTrainerId()==0)
		{
			throw new TrainersException("No record of the given Trainer Id found");
		}
		else{
		return trainer;
		}
	}

	public boolean updateTrainerInfoService(Trainers trainers) {
		// TODO Auto-generated method stub
		boolean trainerUdation=trainersDAO.updateTrainerInfo(trainers);
		if(trainerUdation==false)
		{
			throw new TrainersException("Updation Failed");
		}else{
		return trainerUdation;
		}
	}

	public boolean deleteTrainerService(int trainerId) {
		// TODO Auto-generated method stub
		boolean deletionResult=trainersDAO.deleteTrainer(trainerId);
		if(deletionResult==false)
		{
			throw new TrainersException("Record Deletion Failed");
		}
		return deletionResult;
	}

}
