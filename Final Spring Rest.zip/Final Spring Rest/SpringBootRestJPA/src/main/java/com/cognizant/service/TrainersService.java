package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.Trainers;

public interface TrainersService {
	
	List<Trainers> retriveTrainerRecordsService();
	boolean addingTrainerService(Trainers trainer);
	Trainers retrieveTrainerByIdService(int trainerId);
	boolean updateTrainerInfoService(Trainers trainers);
	boolean deleteTrainerService(int trainerId);
}
