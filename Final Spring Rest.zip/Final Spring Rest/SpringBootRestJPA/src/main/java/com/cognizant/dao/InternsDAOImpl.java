package com.cognizant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.entity.Interns;
import com.cognizant.helper.Levels;
@Repository
public class InternsDAOImpl implements InternsDAO {
	
	@PersistenceContext
	private EntityManager manager;
	
	public List<Interns> getAllInterns() {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("findAllInterns");
		List<Interns> interns=query.getResultList();
		return interns;
	}

	public Interns getInternById(int internId) {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("findInternById");
		query.setParameter("Id", internId);
		return (Interns)query.getSingleResult();
	}

	@Transactional
	public boolean storeInternData(Interns intern) {
		// TODO Auto-generated method stub
		manager.persist(intern);		
		Interns intern_found=getInternById(intern.getInternId());
		if(intern_found!=null){
		return true;}
		else{
			return false;
		}
	}

	@Transactional
	public boolean updateInternLevel(Interns intern) {
		// TODO Auto-generated method stub
		Interns intern_db=getInternById(intern.getInternId());
		Levels intern_Level_updated_before = intern_db.getInternLevel();
		manager.merge(intern);
		Levels intern_Level_updated = intern.getInternLevel();
		if(intern_Level_updated_before==intern_Level_updated)
			return false;
		return true;
	}

	@Transactional
	public boolean deleteInternById(int internId) {
		// TODO Auto-generated method stub
		Interns intern=getInternById(internId);
		manager.remove(intern);
		return true;
	}

}
