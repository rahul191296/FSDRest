package com.cognizant.exception;

public class InternsException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String message;
	
	public InternsException(String message){
		
		this.message=message;
	}

	public String getMessage() {
		return message;
	}

	
	
	

}
