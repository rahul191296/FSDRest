package com.cognizant.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cognizant.entity.Trainers;

@SpringBootApplication
@EnableAutoConfiguration
public class RetrieveAllTrainers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(RetrieveAllTrainers.class, args);
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		RestTemplate restTemplate=new RestTemplate();
		String url="http://localhost:8089/trainers/trainerrecords";
		HttpEntity<String> requestEntity=new HttpEntity<>(headers);
		ResponseEntity<Trainers[]> response=restTemplate.exchange(url, HttpMethod.GET, requestEntity, Trainers[].class);		
		Trainers[] trainers=response.getBody();
		for(Trainers trainer:trainers)
		{
			System.out.println(trainer);
		}
	}

}
