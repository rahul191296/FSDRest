package com.cognizant.client;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.cognizant.entity.Interns;

@SpringBootApplication
@EnableAutoConfiguration
public class DeleteIntern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(DeleteIntern.class, args);
		Interns intern=new Interns();
		int internId=0;
		
		try(
				Scanner scanner=new Scanner(System.in);		
		){
		System.out.print("Please Enter Intern Id:");
		internId=scanner.nextInt();
		intern.setInternId(internId);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		RestTemplate template=new RestTemplate();
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		String url="http://localhost:8089/interns/deleteIntern/{Id}";
		template.delete(url,internId);
	}

}
