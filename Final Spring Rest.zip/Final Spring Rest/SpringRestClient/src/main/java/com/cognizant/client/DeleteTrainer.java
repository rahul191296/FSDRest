package com.cognizant.client;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableAutoConfiguration
public class DeleteTrainer {

	public static void main(String args[])
	{
		SpringApplication.run(DeleteTrainer.class, args);
		int trainerId=0;
		
		try(
			Scanner scanner=new Scanner(System.in);
		){
			System.out.println("Please Enter Trainer Id to be Deleted");
			trainerId=scanner.nextInt();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		RestTemplate restTemplate=new RestTemplate();
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		String url="http://localhost:8089/trainers/deleteTrainer/{trainerId}";
		restTemplate.delete(url,trainerId);
	}
}
