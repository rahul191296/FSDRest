package com.cognizant.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Trainers")
/*
 * Business Entity represents database table Trainers
 */
@NamedQueries(
		{
			@NamedQuery(name="findAllTrainers",query="from Trainers T")
		}
)
public class Trainers {
	@Id
	@Column(name="trainer_id")
	private int trainerId;
	
	@Column(name="trainer_first_name")
	private String trainerFirstName;
	
	@Column(name="trainer_last_name")
	private String trainerLastName;
	
	@Column(name="trainer_age")
	private int trainerAge;
	
	@Column(name="trainer_batch")
	private String trainerBatch;

	public int getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(int trainerId) {
		this.trainerId = trainerId;
	}

	public String getTrainerFirstName() {
		return trainerFirstName;
	}

	public void setTrainerFirstName(String trainerFirstName) {
		this.trainerFirstName = trainerFirstName;
	}

	public String getTrainerLastName() {
		return trainerLastName;
	}

	public void setTrainerLastName(String trainerLastName) {
		this.trainerLastName = trainerLastName;
	}

	public int getTrainerAge() {
		return trainerAge;
	}

	public void setTrainerAge(int trainerAge) {
		this.trainerAge = trainerAge;
	}

	public String getTrainerBatch() {
		return trainerBatch;
	}

	public void setTrainerBatch(String trainerBatch) {
		this.trainerBatch = trainerBatch;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + trainerAge;
		result = prime * result + ((trainerBatch == null) ? 0 : trainerBatch.hashCode());
		result = prime * result + ((trainerFirstName == null) ? 0 : trainerFirstName.hashCode());
		result = prime * result + trainerId;
		result = prime * result + ((trainerLastName == null) ? 0 : trainerLastName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trainers other = (Trainers) obj;
		if (trainerAge != other.trainerAge)
			return false;
		if (trainerBatch == null) {
			if (other.trainerBatch != null)
				return false;
		} else if (!trainerBatch.equals(other.trainerBatch))
			return false;
		if (trainerFirstName == null) {
			if (other.trainerFirstName != null)
				return false;
		} else if (!trainerFirstName.equals(other.trainerFirstName))
			return false;
		if (trainerId != other.trainerId)
			return false;
		if (trainerLastName == null) {
			if (other.trainerLastName != null)
				return false;
		} else if (!trainerLastName.equals(other.trainerLastName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Trainers [trainerId=" + trainerId + ", trainerFirstName=" + trainerFirstName + ", trainerLastName="
				+ trainerLastName + ", trainerAge=" + trainerAge + ", trainerBatch=" + trainerBatch + "]";
	}

}
