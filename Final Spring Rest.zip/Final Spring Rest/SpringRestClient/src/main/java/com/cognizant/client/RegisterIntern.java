package com.cognizant.client;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.cognizant.entity.Interns;

@SpringBootApplication
@EnableAutoConfiguration
public class RegisterIntern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SpringApplication.run(RegisterIntern.class, args);
		Interns intern=new Interns();
		try(
		Scanner scanner=new Scanner(System.in);		
		){
			System.out.print("Please Enter Intern Id:");
			int internId=scanner.nextInt();
			System.out.print("Please Enter Intern First Name:");
			String internFirstName=scanner.next();
			System.out.print("Please Enter Intern Last Name:");
			String internLastName=scanner.next();
			System.out.print("Please Enter Intern Age:");
			int internAge=scanner.nextInt();
			System.out.print("Please Enter Semester 1 Marks:");
			int semesterMarks1=scanner.nextInt();
			
			System.out.print("Please Enter Semester 2 Marks:");
			int semesterMarks2=scanner.nextInt();
			
			System.out.print("Please Enter Semester 3 Marks:");
			int semesterMarks3=scanner.nextInt();
			
			intern.setInternId(internId);
			intern.setInternFirstName(internFirstName);
			intern.setInternLastName(internLastName);
			intern.setInternAge(internAge);
			intern.setSemester1Marks(semesterMarks1);
			intern.setSemester2Marks(semesterMarks2);
			intern.setSemester3Marks(semesterMarks3);
			
			
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
		
		RestTemplate template=new RestTemplate();
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		String url="http://localhost:8089/interns/internpersist";
		template.postForObject(url, intern, Interns.class);
	}

}
