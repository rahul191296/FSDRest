package com.cognizant.client;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.cognizant.entity.Trainers;

@SpringBootApplication
@EnableAutoConfiguration
public class RegisterTrainer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(RegisterTrainer.class, args);
		Trainers trainer=new Trainers();
		
		try(
				Scanner scanner=new Scanner(System.in);
		){
			System.out.println("Please Enter Trainer Details");
			
			System.out.println("Please Enter Trainer ID");
			int trainerId=scanner.nextInt();
			
			System.out.println("Please Enter Trainer's First Name");
			String trainerFirstName=scanner.next();
			
			System.out.println("Please Enter Trainer's Last Name");
			String trainerLastName=scanner.next();
			
			System.out.println("Please Enter Trainer's Age");
			int trainerAge=scanner.nextInt();
			
			System.out.println("Please Enter Trainer's Batch");
			String trainerBatch=scanner.next();

			trainer.setTrainerId(trainerId);
			trainer.setTrainerFirstName(trainerFirstName);
			trainer.setTrainerLastName(trainerLastName);
			trainer.setTrainerAge(trainerAge);
			trainer.setTrainerBatch(trainerBatch);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		RestTemplate restTemplate=new RestTemplate();
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		String url="http://localhost:8089/trainers/addTrainer";
		restTemplate.postForObject(url, trainer, Trainers.class);
		
	}

}
